class Pegawai {
  int? id;
  String nipPegawai;
  String namaPegawai;
  String tglPegawai;
  String nohpPegawai;
  String emailPegawai;
  String pwPegawai;

  Pegawai(
      {this.id,
      required this.nipPegawai,
      required this.namaPegawai,
      required this.tglPegawai,
      required this.nohpPegawai,
      required this.emailPegawai,
      required this.pwPegawai});
}
